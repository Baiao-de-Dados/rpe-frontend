import { MentoringSection } from './Sections/MentoringSection';
import { ReferencesSection } from './Sections/ReferencesSection';

export function EvaluationForm() {
    return (
        <>
            <ReferencesSection />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <br />
            <MentoringSection />
        </>
    );
}
