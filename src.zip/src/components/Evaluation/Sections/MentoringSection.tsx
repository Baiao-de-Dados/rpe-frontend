import MentoringCard from '../Cards/Mentoring';

export function MentoringSection() {
    return (
        <section>
            <MentoringCard />
        </section>
    );
}
