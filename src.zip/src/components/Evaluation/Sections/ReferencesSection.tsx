import { useFieldArray, useFormContext } from 'react-hook-form';
import { AnimatePresence } from 'framer-motion';
import { useState } from 'react';
import SearchBar from '../../Searchbar';
import CollaboratorCard from '../../CollaboratorCard';
import AnimatedCard from '../../AnimatedCard';
import Typography from '../../Typography';
import Reference from '../Cards/Reference';
import { searchCollaborators } from '../../../data/mockCollaborators';
import type { Collaborator } from '../../../data/mockCollaborators';
import type { EvaluationFormData } from '../../../schemas/evaluation';

export function ReferencesSection() {
    const { control, trigger } = useFormContext<EvaluationFormData>();
    const [searchQuery, setSearchQuery] = useState('');

    const { fields, append, remove } = useFieldArray({
        control,
        name: 'references',
    });

    const selectedCollaboratorIds = fields.map(f => f.collaboratorId);

    const selectedCollaborators = (searchCollaboratorIds: string[]) => 
        searchCollaborators('').filter(c => searchCollaboratorIds.includes(c.id));

        const addCollaborator = (collaborator: Collaborator) => {
        append({
            collaboratorId: collaborator.id,
            justification: '',
        });
        setSearchQuery('');
    };

    const removeCollaborator = async (index: number) => {
        remove(index);
        await trigger('references'); 
    };

    return (
        <section>
            <div className="mb-8">
                <SearchBar<Collaborator>
                    value={searchQuery}
                    onChange={setSearchQuery}
                    placeholder="Buscar por colaboradores"
                    className="w-full"
                    searchFunction={searchCollaborators}
                    onItemSelect={addCollaborator}
                    renderItem={collaborator => (
                        <CollaboratorCard
                            collaborator={collaborator}
                            variant="compact"
                        />
                    )}
                    excludeItems={selectedCollaborators(selectedCollaboratorIds)}
                    getItemKey={collaborator => collaborator.id}
                    noResultsMessage="Nenhum colaborador encontrado"
                />
            </div>

            {fields.length > 0 ? (
                <div className="space-y-6">
                    <AnimatePresence>
                        {fields.map((field, index) => {
                            const collaborator = searchCollaborators('').find(
                                c => c.id === field.collaboratorId
                            );
                            if (!collaborator) return null;

                            return (
                                <AnimatedCard key={field.id} index={index}>
                                    <Reference
                                        collaborator={collaborator}
                                        onRemove={() => removeCollaborator(index)} 
                                        name={`references.${index}.justification`}
                                    />
                                </AnimatedCard>
                            );
                        })}
                    </AnimatePresence>
                </div>
            ) : (
                <div className="text-center py-12">
                    <Typography variant="body" className="text-gray-500">
                        Nenhuma referência adicionada
                    </Typography>
                </div>
            )}
        </section>
    );
}
